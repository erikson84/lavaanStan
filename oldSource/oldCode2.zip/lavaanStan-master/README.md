# lavaanStan

Initial source code for fitting Bayesian SEM models using lavaan's syntax and Stan.
